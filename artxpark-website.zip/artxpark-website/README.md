# ArtXpark — 물리 자산 데이터 인프라 구축

## 프로젝트 개요
ArtXpark는 문화 자산의 데이터화, 해석, 자산화를 연결하는 인프라 시스템입니다.

## 배포 방법

### Vercel에 배포하기
1. 이 폴더를 GitHub에 푸시합니다.
2. [Vercel](https://vercel.com)에 접속하여 GitHub 계정으로 로그인합니다.
3. "New Project"를 클릭하고 이 저장소를 선택합니다.
4. 배포 설정을 기본값으로 유지하고 "Deploy"를 클릭합니다.

### 로컬에서 테스트하기
```bash
# 간단한 HTTP 서버로 테스트
python3 -m http.server 8000
```
그 후 브라우저에서 `http://localhost:8000`에 접속합니다.

## 파일 구조
```
artxpark-website/
├── index.html          # 메인 웹사이트 파일
├── vercel.json         # Vercel 배포 설정
└── README.md          # 이 파일
```

## 주요 섹션
- **Hero**: 프로젝트 소개
- **Problem**: 문화 자산 시장의 문제점
- **Solution**: ArtXpark의 솔루션
- **Infrastructure**: 물리 데이터 생성 인프라
- **ARTENA AI**: AI 기반 문화 지능 엔진
- **ArtXbot & ArtXdrone**: 디지털 트윈 스캔 시스템
- **Market**: 시장 규모 및 기회
- **Go-to-Market**: 시장 진출 전략

## 기술 스택
- HTML5
- CSS3 (Vanilla CSS)
- JavaScript (Vanilla JS)
- Responsive Design

## 라이선스
© 2026 ArtXpark Inc. All rights reserved.
